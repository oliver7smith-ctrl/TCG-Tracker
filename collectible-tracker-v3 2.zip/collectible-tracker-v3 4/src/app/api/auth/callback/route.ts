
import { NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
export async function GET(req: NextRequest) {
  const { searchParams, origin } = new URL(req.url)
  const code = searchParams.get("code")
  const next = searchParams.get("next") || "/dashboard"
  if (code) { const s = await createClient(); await s.auth.exchangeCodeForSession(code) }
  return NextResponse.redirect(`${origin}${next}`)
}
